"""RelayAI router: the single source of truth for routing inference.

The math here is lifted verbatim from project1_RelayAI_base_solutions.ipynb, so anything that
consumes this module (the FastAPI backend, the parity test, a notebook) never reimplements it:

    gamma(x) = sigmoid( W2 . ReLU(W1 phi(x) + b1) + b2 )     predicted error, one per model
    r(x)     = argmin over the pool of [ gamma + lambda * cost ]

The network is the notebook's two layer MLP. The hidden layer is shared by every model in the
pool; the output layer holds one row per model, so column j of gamma is the model at
`pool_ids[j]` and nothing else. That is also why the pool is fixed: a model the network has no
output row for cannot be scored, which is exactly the gap the bonus part of the notebook fills.

Free text is embedded by exactly the encoder the dataset was built with,
sentence-transformers/all-MiniLM-L6-v2 with normalize_embeddings=True, cast to float32.
That happens in RelayRouter.embed and nowhere else.

Usage:
    r = RelayRouter.load("router_bundle")
    r.route("How do I balance a redox equation?", lam=0.4)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Sequence

import numpy as np
import torch
import torch.nn as nn

ENCODER_NAME = "sentence-transformers/all-MiniLM-L6-v2"

__all__ = ["MLPRouter", "RelayRouter", "ENCODER_NAME"]


class MLPRouter(nn.Module):
    """gamma_mlp(x) = sigmoid(W2 ReLU(W1 phi(x) + b1) + b2).

    Copied from project1_RelayAI_base_solutions.ipynb. Dropout is a training only device, so
    RelayRouter.load puts this in eval() mode and freezes the weights.
    """

    def __init__(self, d_in: int, n_models: int, hidden: int = 128, p_drop: float = 0.0):
        super().__init__()
        self.fc1 = nn.Linear(d_in, hidden)          # fully connected, 384 -> 128
        self.relu = nn.ReLU()                       # relu activation
        self.drop = nn.Dropout(p_drop)              # dropout between fc1 and fc2
        self.fc2 = nn.Linear(hidden, n_models)      # one output row per model, 128 -> M

    def forward(self, z):
        h = self.drop(self.relu(self.fc1(z)))
        return torch.sigmoid(self.fc2(h))

    def trace(self, z):
        """The same forward pass, but handing back every intermediate the UI explains.

        Returns (hidden, logit, gamma): the 128 post ReLU features, the pre sigmoid score per
        model, and the predicted error itself.
        """
        h = self.relu(self.fc1(z))                  # eval mode, so dropout is the identity
        logit = self.fc2(h)
        return h, logit, torch.sigmoid(logit)


def _to_float(x) -> float:
    """A JSON safe float: NaN and infinities become None at serialisation time."""
    v = float(x)
    return v if np.isfinite(v) else float("nan")


class RelayRouter:
    """Serves the trained router. Weights are read only, nothing is fitted here."""

    def __init__(
        self,
        *,
        meta: dict,
        models: list[dict],
        net: MLPRouter,
        pool_ids: np.ndarray,
        category_accuracy: np.ndarray,
        gamma_by_category: np.ndarray,
        sample_embeddings: np.ndarray,
        sample_categories: np.ndarray,
        sample_prompts: list[dict],
        bundle_dir: Path,
        device: str = "cpu",
    ):
        self.meta = meta
        self.models = models
        self.net = net.eval()
        self.pool_ids = pool_ids.astype(np.int64)              # (M,) catalog ids, column order
        self.category_accuracy = category_accuracy             # (n_catalog, n_categories) measured
        self.gamma_by_category = gamma_by_category             # (M, n_categories) predicted
        self.sample_embeddings = sample_embeddings.astype(np.float32)
        self.sample_categories = sample_categories
        self._sample_prompts = sample_prompts
        self.bundle_dir = Path(bundle_dir)
        self.device = device

        self.dim = int(meta["embedding_dim"])
        self.hidden = int(meta["hidden"])
        self.categories: list[str] = list(meta["categories"])
        self.cost = np.array([m["cost"] for m in models], dtype=np.float32)
        self.default_lambda = float(meta.get("default_lambda", 0.4))

        # column j of every gamma this module returns is the model at pool_ids[j]
        self._col = {int(mid): j for j, mid in enumerate(self.pool_ids)}
        self._encoder = None                                   # loaded on first free text call
        self._gamma_cache: dict[str, np.ndarray] = {}
        self._sample_gamma: np.ndarray | None = None

    # ------------------------------------------------------------------ loading

    @classmethod
    def load(cls, bundle_dir: str | Path, device: str = "cpu") -> "RelayRouter":
        """Read a bundle written by build_router_bundle.py. Nothing is trained here."""
        d = Path(bundle_dir)
        if not d.exists():
            raise FileNotFoundError(
                f"router bundle not found at {d.resolve()}. Build it with: "
                "python build_router_bundle.py"
            )
        meta = json.loads((d / "meta.json").read_text())
        if meta.get("encoder") != ENCODER_NAME:
            raise ValueError(
                f"bundle was built with encoder {meta.get('encoder')!r}, this module serves "
                f"{ENCODER_NAME!r}. Rebuild the bundle."
            )
        if meta.get("architecture") != "mlp":
            raise ValueError(
                f"bundle architecture is {meta.get('architecture')!r}, this module serves the "
                "two layer MLP router of project1_RelayAI_base. Rebuild with: "
                "python build_router_bundle.py"
            )
        models = json.loads((d / "models.json").read_text())
        pool_ids = np.asarray(meta["pool_ids"], dtype=np.int64)
        cat_acc = np.load(d / "category_accuracy.npy").astype(np.float32)
        gamma_cat = np.load(d / "gamma_by_category.npy").astype(np.float32)
        sample_emb = np.load(d / "sample_embeddings.npy").astype(np.float32)
        sample_cat = np.load(d / "sample_categories.npy")
        prompts = json.loads((d / "sample_prompts.json").read_text())

        net = MLPRouter(int(meta["embedding_dim"]), len(pool_ids), hidden=int(meta["hidden"]))
        net.load_state_dict(torch.load(d / "mlp_router.pt", map_location=device))
        net.to(device).eval()
        for p in net.parameters():                             # serve only, never train
            p.requires_grad_(False)

        return cls(meta=meta, models=models, net=net, pool_ids=pool_ids,
                   category_accuracy=cat_acc, gamma_by_category=gamma_cat,
                   sample_embeddings=sample_emb, sample_categories=sample_cat,
                   sample_prompts=prompts, bundle_dir=d, device=device)

    # ------------------------------------------------------------------ encoder

    @property
    def encoder(self):
        """The dataset's own encoder, loaded once, lazily."""
        if self._encoder is None:
            from sentence_transformers import SentenceTransformer

            self._encoder = SentenceTransformer(ENCODER_NAME, device=self.device)
        return self._encoder

    def warm(self) -> None:
        """Load the encoder ahead of the first request, so routing is fast when it matters."""
        _ = self.encoder

    def embed(self, text: str) -> np.ndarray:
        """phi(x): the one and only text to fingerprint path. Returns (d,) float32, L2 normalised."""
        if not isinstance(text, str) or not text.strip():
            raise ValueError("text must be a non empty string")
        vec = self.encoder.encode([text], normalize_embeddings=True,
                                  show_progress_bar=False, convert_to_numpy=True)
        return np.asarray(vec, dtype=np.float32)[0]

    # ------------------------------------------------------------------ pool

    @property
    def deployed(self) -> list[int]:
        """Catalog ids of the models the network has an output row for."""
        return [int(i) for i in self.pool_ids]

    def _resolve_pool(self, pool: Sequence[int] | None) -> np.ndarray:
        """Turn catalog ids into gamma column indices, which is the order everything here uses."""
        if pool is None:
            return np.arange(len(self.pool_ids), dtype=np.int64)
        ids = [int(i) for i in pool]
        unknown = [i for i in ids if not 0 <= i < len(self.models)]
        if unknown:
            raise ValueError(f"unknown model ids: {unknown}")
        outside = [i for i in ids if i not in self._col]
        if outside:
            raise ValueError(
                f"model ids {outside} are not in the served pool. The output layer has one row "
                f"per pool model and no row for these, so the router cannot score them."
            )
        if not ids:
            raise ValueError("the pool is empty, there is nothing to route to")
        return np.asarray([self._col[i] for i in ids], dtype=np.int64)

    # ------------------------------------------------------------------ core math

    def gamma(self, Z: np.ndarray, pool: Sequence[int] | None = None,
              bs: int = 8192) -> np.ndarray:
        """Predicted error for ready made fingerprints, (n, |pool|) in pool order."""
        cols = self._resolve_pool(pool)
        Z = np.atleast_2d(np.asarray(Z, dtype=np.float32))
        out = []
        with torch.no_grad():
            for s in range(0, len(Z), bs):
                blk = torch.tensor(Z[s:s + bs], device=self.device)
                out.append(self.net(blk).cpu().numpy())
        g = np.concatenate(out).astype(np.float32) if out else np.zeros((0, len(cols)), np.float32)
        return g[:, cols]

    def trace(self, text: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """(hidden, logit, gamma) for one question, over the whole pool. Cached per question."""
        if text not in self._gamma_cache:
            z = torch.tensor(self.embed(text)[None, :], device=self.device)
            with torch.no_grad():
                h, logit, g = self.net.trace(z)
            trio = (h.cpu().numpy()[0].astype(np.float32),
                    logit.cpu().numpy()[0].astype(np.float32),
                    g.cpu().numpy()[0].astype(np.float32))
            if len(self._gamma_cache) >= 512:
                self._gamma_cache.clear()
            self._gamma_cache[text] = trio
        return self._gamma_cache[text]

    def looks_like(self, z: np.ndarray, k: int = 25) -> list[dict]:
        """Which topics the k most similar bundled questions belong to.

        The MLP has no clusters to name, so this is the honest replacement: real held out
        questions whose fingerprints sit closest to this one. Embeddings are L2 normalised, so
        the dot product is the cosine.
        """
        sims = self.sample_embeddings @ np.asarray(z, dtype=np.float32)
        top = np.argsort(-sims)[:k]
        cats, counts = np.unique(self.sample_categories[top], return_counts=True)
        order = np.argsort(-counts)
        return [{"category": self.categories[int(cats[j])], "n": int(counts[j]),
                 "share": _to_float(counts[j] / len(top)),
                 "similarity": _to_float(sims[top][self.sample_categories[top] == cats[j]].max())}
                for j in order]

    # ------------------------------------------------------------------ routing

    def route(self, text: str, lam: float | None = None,
              pool: Sequence[int] | None = None, top_k: int = 8) -> dict:
        """Route one question. Returns the pick plus every number behind it.

        The decision is exactly argmin over the pool of (gamma + lam * cost).
        """
        lam = self.default_lambda if lam is None else float(lam)
        if lam < 0:
            raise ValueError("lambda must be zero or positive")
        cols = self._resolve_pool(pool)
        ids = self.pool_ids[cols]

        z = self.embed(text)
        hidden, logit_all, gamma_all = self.trace(text)
        gamma = gamma_all[cols]
        costs = self.cost[ids]
        lam_cost = (lam * costs).astype(np.float32)
        score = gamma + lam_cost                                 # the routing objective
        winner = int(np.argmin(score))                           # the argmin, one model called

        order = np.argsort(score, kind="stable")
        candidates = [self._candidate(int(ids[j]), float(gamma[j]), float(logit_all[cols[j]]),
                                      float(lam_cost[j]), float(score[j]), rank + 1)
                      for rank, j in enumerate(order)]

        chosen = candidates[0]
        runner_ups = candidates[1:1 + max(top_k - 1, 0)]
        margin = float(score[order[1]] - score[order[0]]) if len(order) > 1 else float("nan")

        cheapest = int(ids[int(np.argmin(costs))])
        lowest_gamma = int(ids[int(np.argmin(gamma))])
        active = int((hidden > 0).sum())
        neighbours = self.looks_like(z)

        return {
            "text": text,
            "lam": lam,
            "pool": [int(i) for i in ids],
            "hidden": {
                "units": int(len(hidden)),
                "active": active,
                "active_share": _to_float(active / max(len(hidden), 1)),
                "values": [_to_float(v) for v in hidden],
                "max": _to_float(float(hidden.max())) if len(hidden) else None,
            },
            "looks_like": neighbours,
            "chosen": chosen,
            "candidates": candidates[:top_k],
            "runner_ups": runner_ups,
            "gamma_spread": {
                "min": _to_float(float(gamma.min())),
                "max": _to_float(float(gamma.max())),
                "mean": _to_float(float(gamma.mean())),
            },
            "argmin": {
                "objective": "gamma + lam * cost",
                "n_candidates": int(len(ids)),
                "winning_score": _to_float(score[winner]),
                "margin_over_runner_up": _to_float(margin),
            },
            "why": self._why(chosen, runner_ups, gamma, lam, cheapest, lowest_gamma,
                             margin, neighbours, active, len(hidden)),
        }

    def _candidate(self, model_id: int, gamma: float, logit: float, lam_cost: float,
                   score: float, rank: int) -> dict:
        m = self.models[model_id]
        return {
            "model_id": model_id,
            "name": m["model_name"],
            "short_name": m["short_name"],
            "size_B": m["params_B"],
            "cost": m["cost"],
            "pool": m["pool"],
            "accuracy": m["accuracy"],
            "gamma": _to_float(gamma),
            "logit": _to_float(logit),
            "predicted_accuracy": _to_float(1.0 - gamma),
            "lam_cost": _to_float(lam_cost),
            "score": _to_float(score),
            "rank": rank,
        }

    def _why(self, chosen: dict, runner_ups: list[dict], gamma: np.ndarray, lam: float,
             cheapest: int, lowest_gamma: int, margin: float, neighbours: list[dict],
             active: int, units: int) -> dict:
        """A structured explanation. Plain sentences, no dashes, ready for the UI."""
        rank_by_gamma = int((gamma < chosen["gamma"]).sum()) + 1
        reasons = [
            f"The question's fingerprint lights up {active} of the {units} hidden features, "
            f"and every model in the pool reads that same list.",
            f"From it the output layer predicts {chosen['short_name']} gets this one wrong "
            f"{chosen['gamma'] * 100:.0f}% of the time, the {_ordinal(rank_by_gamma)} lowest "
            f"predicted error of the {len(gamma)} models in the pool.",
        ]
        if neighbours:
            n0 = neighbours[0]
            reasons.append(
                f"Its nearest held out questions are mostly {n0['category']} "
                f"({n0['share'] * 100:.0f}% of the 25 closest), which is the kind of question "
                f"this is.")
        if lam == 0:
            reasons.append("Lambda is zero, so price is ignored and the lowest predicted "
                           "error wins outright.")
        else:
            reasons.append(
                f"At lambda {lam:.3g} its price adds {chosen['lam_cost']:.3f}, for a total of "
                f"{chosen['score']:.3f}, the smallest in the pool.")
        if runner_ups:
            up = runner_ups[0]
            d_gamma = up["gamma"] - chosen["gamma"]
            d_cost = up["lam_cost"] - chosen["lam_cost"]
            gap = ("predicted error" if d_gamma >= d_cost else "price")
            reasons.append(
                f"The runner up {up['short_name']} scores {up['score']:.3f}, "
                f"{abs(margin):.3f} higher, mostly on {gap}.")
        return {
            "reasons": reasons,
            "gamma_rank": rank_by_gamma,
            "gamma_share": _to_float(chosen["gamma"] / chosen["score"]) if chosen["score"] else None,
            "cost_share": _to_float(chosen["lam_cost"] / chosen["score"]) if chosen["score"] else None,
            "is_cheapest_in_pool": chosen["model_id"] == cheapest,
            "is_lowest_predicted_error": chosen["model_id"] == lowest_gamma,
        }

    # ------------------------------------------------------------------ catalog

    def catalog(self) -> dict:
        """The served pool and the full catalog, with size, cost and accuracy."""
        return {
            "deployed": self.deployed,
            "categories": self.categories,
            "default_lambda": self.default_lambda,
            "lambda_max": float(self.meta.get("lambda_max", 10.0)),
            "encoder": ENCODER_NAME,
            "hidden": self.hidden,
            "models": [
                {**{k: m[k] for k in ("model_id", "model_name", "short_name", "publisher",
                                      "family", "params_B", "cost", "pool", "accuracy",
                                      "error_rate")},
                 "deployed": m["model_id"] in self._col}
                for m in self.models
            ],
        }

    def sample_prompts(self) -> list[dict]:
        """Curated student questions, grouped by topic."""
        return [dict(g) for g in self._sample_prompts]

    def topics(self) -> dict:
        """The topics the traffic is made of, with how many held out questions each has."""
        counts = self.meta.get("category_counts", [0] * len(self.categories))
        return {"categories": [{"category": c, "n_prompts": int(n)}
                               for c, n in zip(self.categories, counts)]}

    # ------------------------------------------------------------------ per model stats

    def _sample_gamma_matrix(self) -> np.ndarray:
        """Predicted error for the bundled sample of held out questions, computed once."""
        if self._sample_gamma is None:
            self._sample_gamma = self.gamma(self.sample_embeddings)
        return self._sample_gamma

    def pick_rates(self, lam: float | None = None,
                   pool: Sequence[int] | None = None) -> dict[int, float]:
        """Share of the sample questions each pool member wins at this lambda."""
        lam = self.default_lambda if lam is None else float(lam)
        cols = self._resolve_pool(pool)
        ids = self.pool_ids[cols]
        g = self._sample_gamma_matrix()[:, cols]
        picks = np.argmin(g + float(lam) * self.cost[ids][None, :], axis=1)
        counts = np.bincount(picks, minlength=len(ids))
        n = len(picks)
        return {int(ids[j]): float(counts[j] / n) if n else 0.0 for j in range(len(ids))}

    def model_stats(self, model_id: int, lam: float | None = None,
                    pool: Sequence[int] | None = None) -> dict:
        """Everything the catalog detail view shows for one model."""
        model_id = int(model_id)
        if not 0 <= model_id < len(self.models):
            raise ValueError(f"unknown model id {model_id}")
        lam = self.default_lambda if lam is None else float(lam)
        m = self.models[model_id]
        col = self._col.get(model_id)
        in_pool = col is not None

        acc = self.category_accuracy[model_id]
        pred = self.gamma_by_category[col] if in_pool else np.full(len(self.categories), np.nan)
        by_cat = [{"category": c, "accuracy": _to_float(acc[j]),
                   "predicted_accuracy": _to_float(1.0 - pred[j]), "n_prompts": int(n)}
                  for j, (c, n) in enumerate(zip(self.categories, self.meta["category_counts"]))]
        ranked = sorted([b for b in by_cat if np.isfinite(b["accuracy"])],
                        key=lambda b: b["accuracy"], reverse=True)

        # the model's own slice of the network: one row of W2 plus one bias, and nothing else
        w2 = self.net.fc2.weight.detach().cpu().numpy()
        b2 = self.net.fc2.bias.detach().cpu().numpy()
        row = w2[col] if in_pool else np.zeros(self.hidden, np.float32)

        return {
            "model_id": model_id,
            "name": m["model_name"],
            "short_name": m["short_name"],
            "publisher": m["publisher"],
            "family": m["family"],
            "size_B": m["params_B"],
            "cost": m["cost"],
            "pool": m["pool"],
            "deployed": in_pool,
            "accuracy": m["accuracy"],
            "error_rate": m["error_rate"],
            "output_row": {
                "weights": [_to_float(v) for v in row],
                "bias": _to_float(b2[col]) if in_pool else None,
                "n_numbers": int(self.hidden + 1) if in_pool else 0,
                "abs_mean": _to_float(float(np.abs(row).mean())) if in_pool else None,
            },
            "predicted_error_mean": _to_float(float(np.nanmean(pred))) if in_pool else None,
            "accuracy_by_category": by_cat,
            "best_categories": ranked[:3],
            "worst_categories": ranked[-3:][::-1],
            "pick_rate": self.pick_rates(lam, pool).get(model_id, 0.0) if in_pool else None,
            "pick_rate_lam": lam,
            "pick_rate_n_prompts": int(len(self.sample_embeddings)),
        }

    def _model_brief(self, model_id: int) -> dict:
        """The few fields a leaderboard row needs."""
        m = self.models[int(model_id)]
        return {
            "model_id": int(m["model_id"]),
            "name": m["model_name"],
            "short_name": m["short_name"],
            "params_B": _to_float(m["params_B"]),
            "cost": _to_float(m["cost"]),
            "deployed": int(m["model_id"]) in self._col,
        }

    def category_leaders(self, pool: Sequence[int] | None = None, top: int = 5) -> dict:
        """Per topic, the most accurate models measured on the test split, next to the router's
        own prediction for the same pair. Measured is ground truth, predicted is what gamma says.
        """
        cols = self._resolve_pool(pool)
        ids = self.pool_ids[cols]
        counts = self.meta.get("category_counts", [0] * len(self.categories))
        rows = []
        for j, c in enumerate(self.categories):
            col = self.category_accuracy[:, j]
            # A model with no graded prompt for this topic has no measured accuracy. NaN never
            # compares true, so leaving it in the key leaves the order Python settles on
            # arbitrary and can seat an ungraded model at rank 1. model_stats already drops
            # non-finite scores before ranking; do the same here.
            ranked = sorted((int(i) for i in ids if np.isfinite(col[i])), key=lambda i: -col[i])
            pred_acc = 1.0 - self.gamma_by_category[cols, j]
            # argmax returns the first NaN it meets rather than the best row, so guard it too.
            has_pred = bool(np.any(np.isfinite(pred_acc)))
            best_pred = int(ids[int(np.nanargmax(pred_acc))]) if has_pred else None
            rows.append({
                "category": c,
                "n_prompts": int(counts[j]),
                "leaders": [{**self._model_brief(i), "accuracy": _to_float(col[i]),
                             "predicted_accuracy": _to_float(
                                 1.0 - self.gamma_by_category[self._col[i], j]),
                             "rank": r + 1} for r, i in enumerate(ranked[:top])],
                "pool_mean": _to_float(float(np.nanmean(col[ids]))),
                "router_pick": None if best_pred is None else {
                    **self._model_brief(best_pred),
                    "accuracy": _to_float(col[best_pred]),
                    "predicted_accuracy": _to_float(float(np.nanmax(pred_acc)))},
            })
        return {"measured_on": "test split", "pool_size": len(ids), "categories": rows}

    # ------------------------------------------------------------------ misc

    def info(self) -> dict:
        """Provenance, for the app footer and the README."""
        keys = ("encoder", "architecture", "embedding_dim", "hidden", "seed", "built_utc",
                "n_weights", "train_prompts", "val_prompts", "test_prompts", "n_models",
                "pool_size", "epochs", "batch_size", "learning_rate", "setting", "p_drop",
                "weight_decay", "best_val_mse", "best_epoch", "loss",
                "sample_prompts_for_pick_rate", "default_lambda", "lambda_max",
                "test_report", "baselines", "dataset")
        return {k: self.meta[k] for k in keys if k in self.meta}

    def __repr__(self) -> str:
        return (f"RelayRouter(mlp {self.dim}x{self.hidden}x{len(self.pool_ids)}, "
                f"catalog={len(self.models)}, pool={len(self.pool_ids)})")


def _ordinal(n: int) -> str:
    if 10 <= n % 100 <= 20:
        suffix = "th"
    else:
        suffix = {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
    return f"{n}{suffix}"
