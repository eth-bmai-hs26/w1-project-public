RelayAI Router Explorer
Building Machine Learning and AI Applications, 273-0003-00L
Autumn 2026 - Weekend 1, Project 1

START HERE: open "Installation Guide.pdf" in this folder.
It walks through the whole setup for macOS and for Windows.

The short version, from this folder, in two terminals:

  macOS                                    Windows (PowerShell)
  -----                                    --------------------
  python3 -m venv .venv                    python -m venv .venv
  source .venv/bin/activate                .\.venv\Scripts\Activate.ps1
  pip install -r app/backend/requirements.txt
  python -m uvicorn app.backend.main:app --port 8000

  cd app/frontend                          cd app\frontend
  npm install                              npm install
  npm run dev                              npm run dev

Then open http://localhost:5173

The first backend start downloads the sentence encoder (about 87 MB) and
needs internet. Every run after that works offline.
