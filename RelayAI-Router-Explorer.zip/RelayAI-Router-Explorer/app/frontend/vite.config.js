import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 5173,
    // the FastAPI backend also allows CORS, so a direct call works too
    proxy: {
      "/api": { target: "http://127.0.0.1:8000", changeOrigin: true,
                rewrite: (p) => p.replace(/^\/api/, "") },
    },
  },
});
