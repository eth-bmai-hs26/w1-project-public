import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "./api.js";
import { Badge, ErrorNote, fx, pct } from "./ui.jsx";
import AskPanel from "./components/AskPanel.jsx";
import DecisionPanel from "./components/DecisionPanel.jsx";
import CatalogPanel from "./components/CatalogPanel.jsx";
import ModelDetail from "./components/ModelDetail.jsx";

/** The router's measured accuracy and cost at the lambda nearest the dial, from the bundle. */
function nearestReport(info, lam) {
  const rows = info?.test_report ?? [];
  if (!rows.length) return null;
  return rows.reduce((a, b) => (Math.abs(b.lam - lam) < Math.abs(a.lam - lam) ? b : a));
}

export default function App() {
  const [info, setInfo] = useState(null);
  const [catalog, setCatalog] = useState(null);
  const [groups, setGroups] = useState([]);
  const [pickRates, setPickRates] = useState(null);
  const [topics, setTopics] = useState(null);

  const [lam, setLam] = useState(0.2);
  const [question, setQuestion] = useState("");
  const [result, setResult] = useState(null);
  const [routing, setRouting] = useState(false);
  const [routeError, setRouteError] = useState(null);
  const [bootError, setBootError] = useState(null);

  const [detailId, setDetailId] = useState(null);

  const seq = useRef(0);
  const rateSeq = useRef(0);

  // boot: the router's own description, the catalog, today's questions
  useEffect(() => {
    Promise.all([api.health(), api.models(), api.samplePrompts(), api.categories()])
      .then(([h, c, s, tp]) => {
        setInfo(h);
        setCatalog(c);
        setGroups(s.groups);
        setTopics(tp);
        setLam(s.default_lambda ?? 0.2);
      })
      .catch((e) => setBootError(e.message));
  }, []);

  const runRoute = useCallback(async (text, lamValue) => {
    if (!text) return;
    const mine = ++seq.current;
    setRouting(true);
    setRouteError(null);
    try {
      const res = await api.route(text, lamValue);
      if (mine === seq.current) setResult(res);
    } catch (e) {
      if (mine === seq.current) {
        setResult(null);
        setRouteError(e.message);
      }
    } finally {
      if (mine === seq.current) setRouting(false);
    }
  }, []);

  // one entry point: set the question, the effect below does the routing
  const onRoute = useCallback((text) => setQuestion(text), []);

  // the question and the dial both change often, so route on a short delay, once
  useEffect(() => {
    const t = setTimeout(() => {
      if (question) runRoute(question, lam);
      // Dragging the dial leaves several of these in flight and they do not come back in the
      // order they were sent, so a slow early one would otherwise land last and leave the
      // catalog showing pick rates for a lambda nobody is on. runRoute guards itself the
      // same way; this call had no guard at all.
      const mine = ++rateSeq.current;
      api
        .pickRates(lam)
        .then((p) => {
          if (mine === rateSeq.current) setPickRates(p.rates);
        })
        .catch(() => {
          if (mine === rateSeq.current) setPickRates(null);
        });
    }, 180);
    return () => clearTimeout(t);
  }, [lam, question, runRoute]);

  const report = nearestReport(info, lam);
  const baseline = info?.baselines?.best_single ?? null;

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/85 backdrop-blur">
        <div className="mx-auto flex max-w-[1560px] flex-wrap items-center gap-3 px-5 py-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500 to-plum-500 text-lg shadow-sm">
              &#129517;
            </div>
            <div>
              <h1 className="text-[15px] font-extrabold leading-tight text-slate-900">
                RelayAI Router Explorer
              </h1>
              <p className="text-[11px] leading-tight text-slate-500">
                Every question to the model that should answer it
              </p>
            </div>
          </div>

          <div className="ml-auto flex flex-wrap items-center gap-1.5">
            <Badge tone="brand">lambda {fx(lam, lam >= 1 ? 2 : 3)}</Badge>
            <Badge tone="plum">{catalog ? catalog.deployed.length : "..."} models in the pool</Badge>
            {info && (
              <Badge tone="slate">
                MLP {info.embedding_dim} &#8594; {info.hidden} &#8594; {info.pool_size}
              </Badge>
            )}
            {info && (
              <Badge tone="slate">{info.n_weights.toLocaleString()} weights</Badge>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1560px] px-5 py-5">
        {bootError && (
          <div className="mb-4">
            <ErrorNote>{bootError}</ErrorNote>
          </div>
        )}

        {report && baseline && (
          <div className="mb-4 flex flex-wrap items-center gap-x-5 gap-y-2 rounded-2xl border border-slate-200/80 bg-white px-5 py-3 shadow-sm shadow-slate-200/50">
            <div className="text-[11px] font-bold uppercase tracking-wider text-brand-500">
              at lambda {fx(report.lam, 2)}, on the sealed test split
            </div>
            <div className="flex flex-wrap items-baseline gap-x-5 gap-y-1 text-[12px] text-slate-600">
              <span>
                the router answers at{" "}
                <span className="font-bold text-slate-900">{pct(report.accuracy, 1)}</span> accuracy
                for a mean cost of{" "}
                <span className="font-bold text-slate-900">{fx(report.mean_cost, 3)}</span>
              </span>
              <span className="text-slate-400">|</span>
              <span>
                always calling {baseline.short_name}:{" "}
                <span className="font-semibold text-slate-700">{pct(baseline.accuracy, 1)}</span> at{" "}
                <span className="font-semibold text-slate-700">{fx(baseline.mean_cost, 3)}</span>
              </span>
              <span className="text-slate-400">|</span>
              <span
                title={`Route all ${report.n_questions?.toLocaleString()} test questions and count how many different models win at least one. ${info.pool_size - report.models_used} are never called at all. The busiest one answers ${Math.round(report.top_model_share * 100)}% on its own.`}
                className="cursor-help decoration-slate-300 decoration-dotted underline-offset-2 hover:underline"
              >
                it spreads the work over{" "}
                <span className="font-semibold text-slate-700">{report.models_used}</span> of{" "}
                {info.pool_size} models
                {report.top_model_share >= 0.5 && (
                  <span className="text-amber-600">
                    {" "}
                    but the busiest takes {pct(report.top_model_share, 0)}
                  </span>
                )}
              </span>
            </div>
          </div>
        )}

        <div className="grid items-start gap-4 xl:grid-cols-[minmax(320px,1fr)_minmax(0,1.85fr)]">
          <div className="xl:sticky xl:top-[68px]">
            <AskPanel
              groups={groups}
              lam={lam}
              onLambda={setLam}
              activeQuestion={question}
              onRoute={onRoute}
              loading={routing}
            />
          </div>

          <DecisionPanel
            result={result}
            loading={routing}
            error={routeError}
            lam={lam}
            question={question}
            info={info}
            onOpenModel={setDetailId}
          />
        </div>

        <div className="mt-4">
          <CatalogPanel
            catalog={catalog}
            pickRates={pickRates}
            topics={topics}
            lam={lam}
            chosenId={result?.chosen?.model_id ?? null}
            onOpen={setDetailId}
          />
        </div>

        <footer className="mx-auto mt-6 max-w-3xl pb-8 text-center text-[11px] leading-relaxed text-slate-400">
          {info ? (
            <>
              All inference runs through relay_router.py: gamma = sigmoid(W2 ReLU(W1 phi(x) + b1) +
              b2), then argmin over the pool of gamma + lambda x cost. The network is loaded from
              the bundle and never retrained: {info.n_weights.toLocaleString()} weights fitted on{" "}
              {info.train_prompts?.toLocaleString()} training questions with{" "}
              {info.loss ?? "mean squared error"}, kept at the epoch that validated best (epoch{" "}
              {info.best_epoch + 1}, val MSE {fx(info.best_val_mse, 4)}, {info.setting}). Text is
              embedded by {info.encoder}. Data from {info.dataset?.source}, {info.n_models} models
              in the catalog, {info.pool_size} in today's pool, seed {info.seed}.
            </>
          ) : (
            <>connecting to the router backend at {api.base}</>
          )}
        </footer>
      </main>

      {detailId !== null && (
        <ModelDetail modelId={detailId} lam={lam} info={info} onClose={() => setDetailId(null)} />
      )}
    </div>
  );
}
