// Every call lands on the FastAPI backend, which forwards to relay_router.RelayRouter.
// Nothing in the frontend recomputes gamma, cost or the argmin.

const BASE = (import.meta.env.VITE_API_BASE ?? "http://127.0.0.1:8000").replace(/\/$/, "");

async function request(path, options = {}) {
  let res;
  try {
    res = await fetch(BASE + path, {
      headers: { "content-type": "application/json" },
      ...options,
    });
  } catch (err) {
    throw new Error(
      `cannot reach the router backend at ${BASE}. Start it with: uvicorn app.backend.main:app --port 8000`,
    );
  }
  if (!res.ok) {
    let detail = `${res.status} ${res.statusText}`;
    try {
      const body = await res.json();
      if (body?.detail) detail = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
    } catch {
      /* keep the status line */
    }
    throw new Error(detail);
  }
  return res.json();
}

export const api = {
  base: BASE,
  health: () => request("/health"),
  models: () => request("/models"),
  samplePrompts: () => request("/sample_prompts"),
  topics: () => request("/topics"),
  categories: (top = 5) => request(`/categories?top=${top}`),
  pickRates: (lam) => request(`/pick_rates?lam=${encodeURIComponent(lam)}`),
  modelStats: (id, lam) => request(`/models/${id}/stats?lam=${encodeURIComponent(lam)}`),
  route: (text, lam, pool) =>
    request("/route", {
      method: "POST",
      body: JSON.stringify(pool ? { text, lam, pool } : { text, lam }),
    }),
};
