// Small shared pieces: cards, badges, number formatting, the accuracy colour scale.

export const pct = (v, digits = 0) =>
  v === null || v === undefined || Number.isNaN(v) ? "n/a" : `${(v * 100).toFixed(digits)}%`;

export const fx = (v, digits = 3) =>
  v === null || v === undefined || Number.isNaN(v) ? "n/a" : Number(v).toFixed(digits);

export const sizeLabel = (b) =>
  b === null || b === undefined || Number.isNaN(b) ? "size unknown" : `${Number(b).toFixed(0)}B`;

/** Red through yellow to green, the notebook's heatmap reading: green is better. */
export function accuracyColor(a) {
  if (a === null || a === undefined || Number.isNaN(a)) return "#ececf2";
  const stops = [
    [0.0, [165, 40, 33]],
    [0.25, [214, 96, 63]],
    [0.4, [240, 160, 90]],
    [0.5, [250, 214, 130]],
    [0.6, [214, 227, 145]],
    [0.75, [126, 195, 122]],
    [1.0, [26, 122, 74]],
  ];
  const x = Math.min(Math.max(a, 0), 1);
  for (let i = 1; i < stops.length; i++) {
    if (x <= stops[i][0]) {
      const [x0, c0] = stops[i - 1];
      const [x1, c1] = stops[i];
      const t = (x - x0) / (x1 - x0 || 1);
      const c = c0.map((v, k) => Math.round(v + t * (c1[k] - v)));
      return `rgb(${c[0]}, ${c[1]}, ${c[2]})`;
    }
  }
  return "rgb(26, 122, 74)";
}

/** Readable ink for a heatmap cell: white on the dark ends, slate in the pale middle. */
export function textOn(rgb) {
  const m = /rgb\((\d+),\s*(\d+),\s*(\d+)\)/.exec(rgb || "");
  if (!m) return "#334155";
  const [r, g, b] = [1, 2, 3].map((i) => Number(m[i]) / 255);
  const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return lum > 0.62 ? "#334155" : "#ffffff";
}

export function Card({ children, className = "", ...rest }) {
  return (
    <div
      className={`rounded-2xl border border-slate-200/80 bg-white shadow-sm shadow-slate-200/50 ${className}`}
      {...rest}
    >
      {children}
    </div>
  );
}

export function CardHead({ eyebrow, title, hint, right }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-5 py-4">
      <div>
        {eyebrow && (
          <div className="text-[11px] font-bold uppercase tracking-wider text-brand-500">
            {eyebrow}
          </div>
        )}
        <h2 className="text-[15px] font-extrabold text-slate-900">{title}</h2>
        {hint && <p className="mt-0.5 text-xs leading-relaxed text-slate-500">{hint}</p>}
      </div>
      {right}
    </div>
  );
}

const TONES = {
  brand: "bg-brand-50 text-brand-700 border-brand-100",
  plum: "bg-plum-50 text-plum-700 border-plum-100",
  slate: "bg-slate-50 text-slate-600 border-slate-200",
  green: "bg-emerald-50 text-emerald-700 border-emerald-100",
  amber: "bg-amber-50 text-amber-700 border-amber-100",
};

export function Badge({ children, tone = "slate", className = "" }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-semibold ${TONES[tone]} ${className}`}
    >
      {children}
    </span>
  );
}

export function Stat({ label, value, sub, tone = "slate" }) {
  const color = tone === "brand" ? "text-brand-700" : tone === "plum" ? "text-plum-700" : "text-slate-900";
  return (
    <div className="rounded-xl border border-slate-100 bg-slate-50/60 px-3 py-2.5">
      <div className={`text-lg font-extrabold leading-tight ${color}`}>{value}</div>
      <div className="mt-0.5 text-[10.5px] font-medium uppercase tracking-wide text-slate-500">
        {label}
      </div>
      {sub && <div className="mt-0.5 text-[11px] text-slate-500">{sub}</div>}
    </div>
  );
}

export function Meter({ value, tone = "brand", height = "h-1.5" }) {
  const w = Math.max(0, Math.min(1, value || 0)) * 100;
  const bg =
    tone === "plum"
      ? "bg-gradient-to-r from-plum-400 to-plum-600"
      : tone === "flat"
        ? "bg-slate-400"
        : "bg-gradient-to-r from-brand-500 to-plum-500";
  return (
    <div className={`w-full overflow-hidden rounded-full bg-slate-100 ${height}`}>
      <div className={`${height} rounded-full ${bg}`} style={{ width: `${w}%` }} />
    </div>
  );
}

export function Spinner({ label }) {
  return (
    <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
      <span className="inline-block h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-200 border-t-brand-500" />
      {label}
    </div>
  );
}

export function ErrorNote({ children }) {
  return (
    <div className="rounded-xl border border-red-100 bg-red-50 px-3 py-2 text-xs leading-relaxed text-red-700">
      {children}
    </div>
  );
}
