import { useMemo, useState } from "react";
import { Badge, Card, CardHead, Meter, fx, pct, sizeLabel } from "../ui.jsx";

function ModelCard({ m, pickRate, chosenNow, onOpen }) {
  return (
    <button
      onClick={() => onOpen(m.model_id)}
      className={`group relative overflow-hidden rounded-xl border px-3 py-2.5 text-left transition hover:-translate-y-0.5 hover:shadow-md ${
        chosenNow
          ? "border-brand-300 bg-gradient-to-br from-brand-50 to-plum-50 shadow-sm"
          : "border-slate-200 bg-white hover:border-brand-200"
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="truncate text-[12.5px] font-bold text-slate-800" title={m.model_name}>
            {m.short_name}
          </div>
          <div className="truncate text-[10px] text-slate-400">{m.publisher}</div>
        </div>
        <span className="shrink-0 rounded-md bg-slate-100 px-1.5 py-0.5 text-[10px] font-bold text-slate-600">
          {sizeLabel(m.params_B)}
        </span>
      </div>

      <div className="mt-2 space-y-1.5">
        <div>
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>accuracy</span>
            <span className="font-mono font-semibold text-slate-700">{pct(m.accuracy, 1)}</span>
          </div>
          <Meter value={m.accuracy} />
        </div>
        <div>
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>cost</span>
            <span className="font-mono font-semibold text-slate-700">{fx(m.cost, 2)}</span>
          </div>
          <Meter value={m.cost} tone="plum" />
        </div>
      </div>

      <div className="mt-2 flex items-center justify-between border-t border-slate-100 pt-1.5">
        <span className="text-[10px] text-slate-500">chosen for</span>
        <span
          className={`font-mono text-[11px] font-bold ${
            pickRate > 0 ? "text-brand-700" : "text-slate-300"
          }`}
        >
          {pickRate === undefined ? "n/a" : pct(pickRate, 1)}
        </span>
      </div>
      {chosenNow && (
        <div className="mt-1 text-[10px] font-bold uppercase tracking-wide text-brand-600">
          picked for this question
        </div>
      )}
    </button>
  );
}

// Per topic, the model that actually scored best on the held out split, next to the model the
// router's own gamma rates highest for the same topic. Both come straight from the bundle.
function WhatWinsWhere({ topics, onOpen }) {
  if (!topics) return null;

  return (
    <div className="border-t border-slate-100 px-5 py-4">
      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
        What wins where
      </h3>
      <p className="mb-2 mt-1 text-[10.5px] leading-tight text-slate-400">
        Left is ground truth: the most accurate model in the pool for each topic, measured on the
        held out test split. Right is what the router predicts for the same topic. Where the two
        agree, gamma has learned the topic. Where they differ, it has not, and that gap is what the
        loss curve in the notebook is really about.
      </p>
      <div className="relay-scroll max-h-[340px] overflow-y-auto pr-1">
        <div className="grid gap-1.5">
          {(topics.categories ?? []).map((row) => {
            const best = row.leaders?.[0];
            const pick = row.router_pick;
            if (!best) return null;
            const agree = pick && pick.model_id === best.model_id;
            return (
              <div
                key={row.category}
                className="grid grid-cols-[1fr_auto] items-center gap-x-3 gap-y-1 rounded-xl border border-slate-200 bg-white px-3 py-2 sm:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_minmax(0,1fr)]"
              >
                <div className="min-w-0">
                  <p className="truncate text-[12px] font-semibold text-slate-700">
                    {row.category}
                  </p>
                  <p className="text-[10px] text-slate-400">
                    {row.n_prompts.toLocaleString()} test questions, pool avg{" "}
                    {pct(row.pool_mean, 0)}
                  </p>
                </div>

                <button onClick={() => onOpen(best.model_id)} className="min-w-0 text-left" title={best.name}>
                  <div className="flex items-baseline justify-between gap-2">
                    <p className="truncate text-[12px] font-bold text-brand-600 hover:underline">
                      {best.short_name}
                    </p>
                    <span className="shrink-0 text-[11.5px] font-bold tabular-nums text-slate-800">
                      {pct(best.accuracy, 1)}
                    </span>
                  </div>
                  <Meter value={best.accuracy} />
                  <p className="mt-0.5 text-[9.5px] uppercase tracking-wide text-slate-400">
                    measured best
                  </p>
                </button>

                {pick && (
                  <button
                    onClick={() => onOpen(pick.model_id)}
                    className="min-w-0 text-left"
                    title={pick.name}
                  >
                    <div className="flex items-baseline justify-between gap-2">
                      <p className="truncate text-[12px] font-bold text-plum-600 hover:underline">
                        {pick.short_name}
                      </p>
                      <span className="shrink-0 text-[11.5px] font-bold tabular-nums text-slate-800">
                        {pct(pick.accuracy, 1)}
                      </span>
                    </div>
                    <Meter value={pick.predicted_accuracy} tone="plum" />
                    <p className="mt-0.5 flex items-center gap-1 text-[9.5px] uppercase tracking-wide text-slate-400">
                      router's pick
                      {agree && <span className="font-bold text-emerald-600">match</span>}
                    </p>
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default function CatalogPanel({ catalog, pickRates, lam, chosenId, onOpen, topics }) {
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("pick");

  const deployed = useMemo(() => {
    if (!catalog) return [];
    const byId = new Map(catalog.models.map((m) => [m.model_id, m]));
    const list = catalog.deployed.map((id) => byId.get(id)).filter(Boolean);
    const q = query.trim().toLowerCase();
    const filtered = q
      ? list.filter(
          (m) =>
            m.short_name.toLowerCase().includes(q) ||
            m.publisher.toLowerCase().includes(q) ||
            m.family.toLowerCase().includes(q),
        )
      : list;
    const rate = (m) => pickRates?.[String(m.model_id)] ?? -1;
    const cmp = {
      pick: (a, b) => rate(b) - rate(a) || b.accuracy - a.accuracy,
      accuracy: (a, b) => b.accuracy - a.accuracy,
      cheapest: (a, b) => a.cost - b.cost,
      priciest: (a, b) => b.cost - a.cost,
      name: (a, b) => a.short_name.localeCompare(b.short_name),
    }[sort];
    return [...filtered].sort(cmp);
  }, [catalog, pickRates, query, sort]);

  const total = catalog?.deployed?.length ?? 0;
  const active = pickRates ? Object.values(pickRates).filter((v) => v > 0).length : null;

  return (
    <Card className="relay-rise">
      <CardHead
        eyebrow="Panel 3"
        title="Catalog"
        hint="The 70 models available today, one output row each. Click one to see what it is good at."
      />

      <div className="flex flex-wrap items-center gap-2 border-b border-slate-100 px-5 py-3">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="search the pool"
          className="min-w-[160px] flex-1 rounded-xl border border-slate-200 bg-slate-50/60 px-3 py-1.5 text-[12.5px] outline-none transition focus:border-brand-300 focus:bg-white focus:ring-2 focus:ring-brand-100"
        />
        <div className="flex flex-wrap gap-1">
          {[
            ["pick", "most chosen"],
            ["accuracy", "most accurate"],
            ["cheapest", "cheapest"],
            ["priciest", "priciest"],
            ["name", "a to z"],
          ].map(([key, label]) => (
            <button
              key={key}
              onClick={() => setSort(key)}
              className={`rounded-lg px-2 py-1 text-[11px] font-semibold transition ${
                sort === key
                  ? "bg-brand-500 text-white"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 px-5 pt-3 text-[11px] text-slate-500">
        <Badge tone="brand">{total} models in the pool</Badge>
        {active !== null && <Badge tone="plum">{active} ever chosen at lambda {fx(lam, 3)}</Badge>}
        <span className="text-slate-400">
          pick rates are measured over the bundle's held out sample questions
        </span>
      </div>

      <div className="grid gap-2 px-5 py-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {deployed.map((m) => (
          <ModelCard
            key={m.model_id}
            m={m}
            pickRate={pickRates ? (pickRates[String(m.model_id)] ?? 0) : undefined}
            chosenNow={m.model_id === chosenId}
            onOpen={onOpen}
          />
        ))}
        {!deployed.length && (
          <p className="col-span-full py-8 text-center text-xs text-slate-400">
            Nothing matches that search.
          </p>
        )}
      </div>

      <WhatWinsWhere topics={topics} onOpen={onOpen} />
    </Card>
  );
}
