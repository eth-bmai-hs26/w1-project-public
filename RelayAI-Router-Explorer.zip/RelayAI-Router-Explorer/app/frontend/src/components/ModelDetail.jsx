import { useEffect, useState } from "react";
import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api } from "../api.js";
import {
  Badge,
  ErrorNote,
  Meter,
  Spinner,
  Stat,
  accuracyColor,
  fx,
  pct,
  sizeLabel,
  textOn,
} from "../ui.jsx";

const INDIGO = "#667eea";
const PLUM = "#a36ddc";

function Heatmap({ rows }) {
  return (
    <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3 lg:grid-cols-4">
      {rows.map((row) => {
        const bg = accuracyColor(row.accuracy);
        return (
          <div
            key={row.category}
            className="rounded-lg px-2.5 py-2"
            style={{ background: bg, color: textOn(bg) }}
            title={`${row.category}: ${pct(row.accuracy, 1)} on ${row.n_prompts} test prompts`}
          >
            <div className="text-[15px] font-extrabold leading-none">{pct(row.accuracy, 0)}</div>
            <div className="mt-1 text-[10px] font-medium leading-tight opacity-90">
              {row.category}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function TopicChart({ rows }) {
  const data = (rows || []).map((r) => ({
    topic: r.category.length > 14 ? `${r.category.slice(0, 13)}...` : r.category,
    full: r.category,
    measured: r.accuracy,
    predicted: r.predicted_accuracy,
  }));
  return (
    <div className="h-[176px] w-full">
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 4, right: 4, left: 0, bottom: 38 }}>
          <XAxis
            dataKey="topic"
            tick={{ fontSize: 9, fill: "#94a3b8" }}
            axisLine={false}
            tickLine={false}
            interval={0}
            angle={-35}
            textAnchor="end"
          />
          <YAxis
            domain={[0, 1]}
            tick={{ fontSize: 10, fill: "#94a3b8" }}
            axisLine={false}
            tickLine={false}
            width={30}
            tickFormatter={(v) => `${Math.round(v * 100)}%`}
          />
          <Tooltip
            formatter={(v, key) => [pct(v, 1), key === "measured" ? "measured" : "predicted"]}
            labelFormatter={(l, pl) => pl?.[0]?.payload?.full ?? l}
            contentStyle={{ fontSize: 11, borderRadius: 10, border: "1px solid #e2e8f0" }}
          />
          <Bar dataKey="measured" fill={INDIGO} radius={[3, 3, 0, 0]} />
          <Bar dataKey="predicted" fill={PLUM} radius={[3, 3, 0, 0]} fillOpacity={0.75} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export default function ModelDetail({ modelId, lam, info, onClose }) {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState(null);
  // The pool is whatever the loaded bundle says it is, so read it rather than writing 70 and 42
  // into the copy: rebuilding the bundle with a different pool used to leave this paragraph
  // quietly wrong, and the held out branch rendered "shared by all  pool models".
  const poolSize = info?.pool_size ?? null;
  const heldOut =
    info?.n_models != null && info?.pool_size != null ? info.n_models - info.pool_size : null;

  useEffect(() => {
    let alive = true;
    setStats(null);
    setError(null);
    api
      .modelStats(modelId, lam)
      .then((s) => alive && setStats(s))
      .catch((e) => alive && setError(e.message));
    return () => {
      alive = false;
    };
  }, [modelId, lam]);

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-40 flex items-start justify-center overflow-y-auto bg-slate-900/40 p-4 backdrop-blur-sm relay-scroll"
      onClick={onClose}
    >
      <div
        className="relay-rise my-6 w-full max-w-3xl rounded-2xl bg-white shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 rounded-t-2xl bg-gradient-to-r from-brand-500 to-plum-500 px-5 py-4 text-white">
          <div className="min-w-0">
            <div className="text-[10.5px] font-bold uppercase tracking-wider text-white/75">
              {stats ? stats.publisher : "catalog model"}
            </div>
            <h2 className="truncate text-lg font-extrabold">
              {stats ? stats.short_name : `model ${modelId}`}
            </h2>
            {stats && (
              <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                <span className="rounded-full bg-white/20 px-2 py-0.5 text-[11px] font-semibold">
                  {sizeLabel(stats.size_B)}
                </span>
                <span className="rounded-full bg-white/20 px-2 py-0.5 text-[11px] font-semibold">
                  cost {fx(stats.cost, 2)}
                </span>
                <span className="rounded-full bg-white/20 px-2 py-0.5 text-[11px] font-semibold">
                  {stats.deployed ? "in the pool" : "held out for the bonus part"}
                </span>
              </div>
            )}
          </div>
          <button
            onClick={onClose}
            className="shrink-0 rounded-lg bg-white/15 px-2.5 py-1 text-sm font-bold text-white transition hover:bg-white/25"
            aria-label="close"
          >
            &#10005;
          </button>
        </div>

        <div className="space-y-4 px-5 py-4">
          {error && <ErrorNote>{error}</ErrorNote>}
          {!stats && !error && (
            <div className="py-10 text-center">
              <Spinner label="reading the router" />
            </div>
          )}

          {stats && (
            <>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <Stat label="catalog accuracy" value={pct(stats.accuracy, 1)} tone="brand" />
                <Stat label="cost" value={fx(stats.cost, 2)} sub={sizeLabel(stats.size_B)} />
                <Stat
                  label={`chosen at lambda ${fx(lam, 3)}`}
                  value={stats.pick_rate === null ? "not in pool" : pct(stats.pick_rate, 1)}
                  sub={`of ${stats.pick_rate_n_prompts} sample prompts`}
                  tone="plum"
                />
                <Stat
                  label="predicted error"
                  value={fx(stats.predicted_error_mean, 3)}
                  sub="what gamma says, on average"
                />
              </div>

              {stats.pick_rate !== null && (
                <div>
                  <div className="mb-1 flex items-baseline justify-between text-[11px] text-slate-500">
                    <span>share of the sample pool routed here</span>
                    <span className="font-mono font-semibold text-slate-700">
                      {pct(stats.pick_rate, 1)}
                    </span>
                  </div>
                  <Meter value={stats.pick_rate} />
                </div>
              )}

              <div>
                <h3 className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-500">
                  Accuracy by topic, on held out test questions
                </h3>
                <Heatmap rows={stats.accuracy_by_category} />
                <p className="mt-1.5 text-[10.5px] text-slate-400">
                  Green is better. This is the raw material the router exploits.
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div className="rounded-xl border border-emerald-100 bg-emerald-50/50 px-3 py-2.5">
                  <h4 className="text-[11px] font-bold uppercase tracking-wide text-emerald-700">
                    Best topics
                  </h4>
                  <ul className="mt-1 space-y-1">
                    {stats.best_categories.map((b) => (
                      <li key={b.category} className="flex justify-between gap-2 text-[12px]">
                        <span className="min-w-0 truncate text-slate-700">{b.category}</span>
                        <span className="font-mono font-semibold text-emerald-700">
                          {pct(b.accuracy, 1)}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="rounded-xl border border-red-100 bg-red-50/50 px-3 py-2.5">
                  <h4 className="text-[11px] font-bold uppercase tracking-wide text-red-700">
                    Worst topics
                  </h4>
                  <ul className="mt-1 space-y-1">
                    {stats.worst_categories.map((b) => (
                      <li key={b.category} className="flex justify-between gap-2 text-[12px]">
                        <span className="min-w-0 truncate text-slate-700">{b.category}</span>
                        <span className="font-mono font-semibold text-red-700">
                          {pct(b.accuracy, 1)}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div>
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    What the router believes, next to what happened
                  </h3>
                  <div className="flex items-center gap-3 text-[10.5px] text-slate-500">
                    <span className="flex items-center gap-1">
                      <span className="inline-block h-2.5 w-2.5 rounded-sm bg-brand-500" />
                      measured
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="inline-block h-2.5 w-2.5 rounded-sm bg-plum-500" />
                      predicted
                    </span>
                  </div>
                </div>
                <p className="mb-1 text-[10.5px] text-slate-400">
                  Accuracy per topic on the test questions, against the accuracy this model's own
                  output row predicts for them. Two bars the same height means gamma has this model
                  right.
                </p>
                <TopicChart rows={stats.accuracy_by_category} />
              </div>

              <div className="rounded-xl border border-slate-100 bg-slate-50/60 px-3 py-2.5">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  This model's slice of the network
                </h3>
                <p className="mt-1 text-[11.5px] leading-relaxed text-slate-600">
                  The hidden layer is shared by all {poolSize ?? "the"} pool models.{" "}
                  {stats.deployed ? (
                    <>
                      What belongs to {stats.short_name} alone is one row of{" "}
                      <span className="font-mono text-slate-700">W2</span> plus one bias, which is{" "}
                      <span className="font-bold text-slate-800">
                        {stats.output_row.n_numbers} numbers
                      </span>
                      {stats.output_row.abs_mean !== null && (
                        <> with a mean magnitude of {fx(stats.output_row.abs_mean, 3)}</>
                      )}
                      .
                    </>
                  ) : (
                    <>
                      {stats.short_name} has no row of{" "}
                      <span className="font-mono text-slate-700">W2</span> at all, so the router
                      cannot score it.
                    </>
                  )}{" "}
                  Adding a model to the catalog means growing{" "}
                  <span className="font-mono text-slate-700">W2</span> by a row and fitting those
                  numbers from scratch, which is why the {heldOut ?? "held out"} models outside the
                  pool cannot be scored at all.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-1.5 border-t border-slate-100 pt-3">
                <Badge tone="slate">model id {stats.model_id}</Badge>
                <Badge tone="slate">family {stats.family}</Badge>
                <Badge tone="slate">
                  {stats.pool === "test" ? "never seen in training" : "training pool model"}
                </Badge>
                <Badge tone="slate">{stats.name}</Badge>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
