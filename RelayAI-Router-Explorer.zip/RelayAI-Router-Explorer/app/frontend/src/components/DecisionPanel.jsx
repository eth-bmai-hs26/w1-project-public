import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Badge, Card, CardHead, ErrorNote, Meter, Spinner, fx, pct, sizeLabel } from "../ui.jsx";

const INDIGO = "#667eea";
const PLUM = "#a36ddc";

function StageArrow() {
  return (
    <div className="hidden shrink-0 items-center justify-center px-1 text-lg text-slate-300 lg:flex">
      &#10230;
    </div>
  );
}

function Stage({ step, title, formula, children, tone = "brand" }) {
  const ring = tone === "plum" ? "border-plum-200 bg-plum-50/50" : "border-brand-200 bg-brand-50/40";
  return (
    <div className={`min-w-0 flex-1 rounded-xl border ${ring} px-3 py-2.5`}>
      <div className="flex items-baseline gap-1.5">
        <span className="text-[10px] font-extrabold text-slate-400">{step}</span>
        <span className="text-[12px] font-bold text-slate-800">{title}</span>
      </div>
      <div className="mt-0.5 font-mono text-[10.5px] text-slate-500">{formula}</div>
      <div className="mt-2">{children}</div>
    </div>
  );
}

/** The 128 post-ReLU features as a strip. Dark where a unit fired, pale where ReLU zeroed it. */
function HiddenStrip({ hidden }) {
  const values = hidden?.values ?? [];
  const max = hidden?.max || 1;
  return (
    <div>
      <div className="flex h-[54px] w-full items-end gap-[1px] overflow-hidden rounded-md bg-slate-100 px-[2px] pb-[2px] pt-[2px]">
        {values.map((v, i) => (
          <div
            key={i}
            title={`unit ${i}: ${fx(v, 3)}`}
            className="min-w-0 flex-1 rounded-[1px]"
            style={{
              height: `${Math.max((v / max) * 100, 3)}%`,
              background: v > 0 ? INDIGO : "#e2e8f0",
              opacity: v > 0 ? 0.35 + 0.65 * (v / max) : 1,
            }}
          />
        ))}
      </div>
      <div className="mt-1 text-[10.5px] text-slate-500">
        <span className="font-semibold text-slate-700">{hidden?.active}</span> of {hidden?.units}{" "}
        units fired, the rest ReLU set to zero
      </div>
    </div>
  );
}

function CandidateChart({ candidates, winnerId, lam }) {
  const data = candidates.map((c) => ({
    name: c.short_name.length > 22 ? `${c.short_name.slice(0, 21)}...` : c.short_name,
    gamma: c.gamma,
    lam_cost: c.lam_cost,
    score: c.score,
    id: c.model_id,
  }));
  const height = Math.max(data.length * 30 + 34, 150);

  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer>
        <BarChart data={data} layout="vertical" margin={{ top: 4, right: 46, left: 4, bottom: 4 }}>
          <XAxis
            type="number"
            tick={{ fontSize: 10, fill: "#94a3b8" }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            type="category"
            dataKey="name"
            width={148}
            tick={{ fontSize: 10.5, fill: "#475569" }}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip
            contentStyle={{ fontSize: 11, borderRadius: 10, border: "1px solid #e2e8f0" }}
            formatter={(v, key) => [
              fx(v, 4),
              key === "gamma" ? "predicted error gamma" : `lambda x cost (lambda ${fx(lam, 3)})`,
            ]}
          />
          <Bar dataKey="gamma" stackId="s" radius={[3, 0, 0, 3]}>
            {data.map((d) => (
              <Cell key={d.id} fill={INDIGO} fillOpacity={d.id === winnerId ? 1 : 0.42} />
            ))}
          </Bar>
          <Bar dataKey="lam_cost" stackId="s" radius={[0, 3, 3, 0]}>
            {data.map((d) => (
              <Cell key={d.id} fill={PLUM} fillOpacity={d.id === winnerId ? 1 : 0.42} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

function Hero({ result, onOpenModel }) {
  const c = result.chosen;
  const gammaShare = c.score ? c.gamma / c.score : 1;
  return (
    <div className="rounded-2xl bg-gradient-to-br from-brand-500 to-plum-500 p-[1.5px] shadow-md shadow-brand-200/60">
      <div className="rounded-2xl bg-white px-4 py-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="text-[10.5px] font-bold uppercase tracking-wider text-brand-500">
              the router calls
            </div>
            <button
              onClick={() => onOpenModel(c.model_id)}
              className="mt-0.5 block max-w-full truncate text-left text-xl font-extrabold text-slate-900 hover:text-brand-700"
              title={c.name}
            >
              {c.short_name}
            </button>
            <div className="mt-1 flex flex-wrap items-center gap-1.5">
              <Badge tone="brand">{sizeLabel(c.size_B)}</Badge>
              <Badge tone="plum">cost {fx(c.cost, 2)}</Badge>
              <Badge tone="slate">catalog accuracy {pct(c.accuracy, 1)}</Badge>
              {result.why.is_lowest_predicted_error && (
                <Badge tone="green">lowest predicted error</Badge>
              )}
              {result.why.is_cheapest_in_pool && <Badge tone="amber">cheapest in pool</Badge>}
            </div>
          </div>

          <div className="grid shrink-0 grid-cols-3 gap-2 text-center">
            {[
              ["gamma", fx(c.gamma, 3), "predicted error"],
              ["lambda x cost", fx(c.lam_cost, 3), "price term"],
              ["score", fx(c.score, 3), "the argmin"],
            ].map(([label, value, sub]) => (
              <div key={label} className="rounded-xl border border-slate-100 bg-slate-50/70 px-2.5 py-2">
                <div className="font-mono text-[10px] text-slate-400">{label}</div>
                <div className="text-base font-extrabold text-slate-900">{value}</div>
                <div className="text-[9.5px] text-slate-400">{sub}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-3">
          <div className="flex h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
            <div
              className="h-full bg-brand-500"
              style={{ width: `${gammaShare * 100}%` }}
              title="predicted error share"
            />
            <div
              className="h-full bg-plum-500"
              style={{ width: `${(1 - gammaShare) * 100}%` }}
              title="price share"
            />
          </div>
          <div className="mt-1 flex justify-between text-[10.5px] text-slate-500">
            <span>
              predicted error {pct(gammaShare, 0)} of the score, so predicted accuracy{" "}
              <span className="font-semibold text-slate-700">{pct(c.predicted_accuracy, 1)}</span>
            </span>
            <span>price {pct(1 - gammaShare, 0)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function DecisionPanel({ result, loading, error, lam, question, info, onOpenModel }) {
  const near = result?.looks_like?.[0] ?? null;
  // Shapes come from the loaded bundle, not from the copy. These read 384 -> 128 -> 70 and
  // "129 numbers each" today, and said exactly that even when a rebuilt bundle disagreed.
  const dIn = info?.embedding_dim ?? null;
  const dHid = result?.hidden?.units ?? info?.hidden ?? null;
  const nPool = result?.argmin?.n_candidates ?? info?.pool_size ?? null;
  const perRow = dHid == null ? null : dHid + 1;
  return (
    <Card className="relay-rise">
      <CardHead
        eyebrow="Panel 2"
        title="Decision"
        hint="gamma = sigmoid(W2 ReLU(W1 phi(x) + b1) + b2), then plus lambda x cost, then argmin."
        right={loading ? <Spinner label="routing" /> : null}
      />

      <div className="space-y-4 px-5 py-4">
        {error && <ErrorNote>{error}</ErrorNote>}

        {!result && !error && (
          <div className="rounded-xl border border-dashed border-slate-200 px-4 py-10 text-center">
            <div className="text-2xl">&#129517;</div>
            <p className="mt-2 text-sm font-semibold text-slate-600">No question routed yet</p>
            <p className="mt-1 text-xs text-slate-400">
              Pick a question on the left, or type your own.
            </p>
          </div>
        )}

        {result && (
          <>
            <div className="rounded-xl border border-slate-100 bg-slate-50/70 px-3 py-2">
              <div className="flex items-baseline justify-between gap-2">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  the question
                </div>
                {near && (
                  <span className="text-[10px] text-slate-400">
                    reads like{" "}
                    <span className="font-semibold text-slate-600">{near.category}</span>
                  </span>
                )}
              </div>
              <p className="mt-0.5 max-h-24 overflow-y-auto whitespace-pre-wrap text-[12px] leading-relaxed text-slate-600 relay-scroll">
                {question}
              </p>
            </div>

            <Hero result={result} onOpenModel={onOpenModel} />

            <div>
              <h3 className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-500">
                How the number was built
              </h3>
              <div className="flex flex-col gap-2 lg:flex-row lg:items-stretch">
                <Stage
                  step="1"
                  title="hidden layer"
                  formula={`ReLU(W1 phi(x) + b1)${dIn && dHid ? `, ${dIn} -> ${dHid}` : ""}`}
                >
                  <HiddenStrip hidden={result.hidden} />
                  <div className="mt-1 text-[10.5px] leading-snug text-slate-400">
                    shared: every model in the pool reads this same list
                  </div>
                </Stage>
                <StageArrow />
                <Stage
                  step="2"
                  title="output layer"
                  formula={`sigmoid(W2 h + b2)${dHid && nPool ? `, ${dHid} -> ${nPool}` : ""}`}
                >
                  <div className="space-y-1.5">
                    {[
                      ["models scored", result.argmin.n_candidates],
                      ["lowest gamma", fx(result.gamma_spread.min, 3)],
                      ["winner gamma", fx(result.chosen.gamma, 3)],
                      ["pool average", fx(result.gamma_spread.mean, 3)],
                    ].map(([k, v]) => (
                      <div key={k} className="flex items-baseline justify-between gap-2">
                        <span className="text-[10.5px] text-slate-500">{k}</span>
                        <span className="font-mono text-[12px] font-bold text-slate-800">{v}</span>
                      </div>
                    ))}
                    <div className="pt-1 text-[10px] leading-snug text-slate-400">
                      one row of W2 per model{perRow ? `, ${perRow} numbers each` : ""}
                    </div>
                  </div>
                </Stage>
                <StageArrow />
                <Stage
                  step="3"
                  title="plus lambda x cost, argmin"
                  formula={`lambda = ${fx(lam, 3)}`}
                  tone="plum"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="text-[10.5px] text-slate-500">winning score</span>
                      <span className="font-mono text-[12px] font-bold text-plum-700">
                        {fx(result.argmin.winning_score, 3)}
                      </span>
                    </div>
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="text-[10.5px] text-slate-500">margin over runner up</span>
                      <span className="font-mono text-[12px] font-bold text-slate-800">
                        {fx(result.argmin.margin_over_runner_up, 4)}
                      </span>
                    </div>
                    <Meter
                      value={
                        result.argmin.margin_over_runner_up /
                        Math.max(result.argmin.winning_score, 1e-6)
                      }
                      tone="plum"
                    />
                    <div className="pt-0.5 text-[10px] leading-snug text-slate-400">
                      exactly one model is called
                    </div>
                  </div>
                </Stage>
              </div>
            </div>

            <div>
              <div className="mb-1 flex items-baseline justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Top candidates, score split in two
                </h3>
                <div className="flex items-center gap-3 text-[10.5px] text-slate-500">
                  <span className="flex items-center gap-1">
                    <span className="inline-block h-2.5 w-2.5 rounded-sm bg-brand-500" />
                    gamma
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="inline-block h-2.5 w-2.5 rounded-sm bg-plum-500" />
                    lambda x cost
                  </span>
                </div>
              </div>
              <CandidateChart
                candidates={result.candidates}
                winnerId={result.chosen.model_id}
                lam={lam}
              />
              <p className="text-[10.5px] text-slate-400">
                Shorter is better. The full bar is the score, the winner is the solid one.
              </p>
            </div>

            <div className="grid gap-3 lg:grid-cols-2">
              <div className="rounded-xl border border-slate-100 bg-white px-3 py-3">
                <h3 className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-500">
                  Why this one won
                </h3>
                <ul className="space-y-1.5">
                  {result.why.reasons.map((reason, i) => (
                    <li key={i} className="flex gap-2 text-[12px] leading-relaxed text-slate-600">
                      <span className="mt-[3px] inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-gradient-to-r from-brand-500 to-plum-500" />
                      {reason}
                    </li>
                  ))}
                </ul>
                {result.looks_like?.length > 0 && (
                  <div className="mt-2.5 border-t border-slate-100 pt-2">
                    <div className="text-[10px] font-bold uppercase tracking-wide text-slate-400">
                      nearest held out questions
                    </div>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {result.looks_like.slice(0, 4).map((n) => (
                        <Badge key={n.category} tone={n === result.looks_like[0] ? "brand" : "slate"}>
                          {n.category} {pct(n.share, 0)}
                        </Badge>
                      ))}
                    </div>
                    <p className="mt-1 text-[10px] leading-snug text-slate-400">
                      The 25 closest fingerprints by cosine. The network never sees a topic label,
                      this is only here to say what kind of question arrived.
                    </p>
                  </div>
                )}
              </div>

              <div className="rounded-xl border border-slate-100 bg-white px-3 py-3">
                <h3 className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-500">
                  Runner ups
                </h3>
                <div className="space-y-1">
                  {result.runner_ups.slice(0, 5).map((c) => (
                    <button
                      key={c.model_id}
                      onClick={() => onOpenModel(c.model_id)}
                      className="flex w-full items-center gap-2 rounded-lg px-1.5 py-1 text-left transition hover:bg-brand-50/60"
                    >
                      <span className="w-4 text-[10.5px] font-bold text-slate-300">{c.rank}</span>
                      <span className="min-w-0 flex-1 truncate text-[12px] font-semibold text-slate-700">
                        {c.short_name}
                      </span>
                      <span className="font-mono text-[11px] text-slate-500">{fx(c.score, 3)}</span>
                      <span className="w-14 text-right font-mono text-[10.5px] text-slate-400">
                        +{fx(c.score - result.chosen.score, 3)}
                      </span>
                    </button>
                  ))}
                  {!result.runner_ups.length && (
                    <p className="text-[11.5px] text-slate-400">
                      Only one model in the pool, so there is nothing to compare.
                    </p>
                  )}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </Card>
  );
}
