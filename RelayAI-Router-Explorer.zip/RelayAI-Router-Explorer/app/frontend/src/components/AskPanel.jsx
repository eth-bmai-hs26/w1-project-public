import { useMemo, useState } from "react";
import { Card, CardHead, Badge, Spinner, fx } from "../ui.jsx";

// The notebook sweeps lambda over np.linspace(0, 10, 1000). Everything interesting happens below
// about 0.6, so the slider walks a geometric grid: zero, then 0.005 up to the notebook's 10.
const ASCENDING = [
  0,
  ...Array.from({ length: 26 }, (_, i) => Math.pow(10, -2.3 + (3.3 * i) / 25)),
];
// the slider reads left to right as cost first through quality first, so lambda descends
export const LAMBDA_STEPS = [...ASCENDING].reverse();

export function nearestLambdaIndex(lam) {
  let best = 0;
  for (let i = 1; i < LAMBDA_STEPS.length; i++) {
    if (Math.abs(LAMBDA_STEPS[i] - lam) < Math.abs(LAMBDA_STEPS[best] - lam)) best = i;
  }
  return best;
}

function regime(lam) {
  if (lam === 0) return "spare no expense, price is ignored";
  if (lam < 0.05) return "quality leaning, price barely counts";
  if (lam < 0.3) return "balanced, the interesting middle";
  if (lam < 0.8) return "cost leaning, the small models start winning";
  return "save money, one cheap model answers almost everything";
}

export default function AskPanel({ groups, lam, onLambda, onRoute, loading, activeQuestion }) {
  const [draft, setDraft] = useState("");
  const [cursor, setCursor] = useState({});

  const chips = useMemo(
    () =>
      (groups || [])
        .filter((g) => g.questions?.length)
        .map((g) => {
          const i = (cursor[g.topic] || 0) % g.questions.length;
          return { group: g, index: i, question: g.questions[i] };
        }),
    [groups, cursor],
  );

  const clickChip = (chip) => {
    const isActive = activeQuestion === chip.question.text;
    if (isActive) {
      const next = (chip.index + 1) % chip.group.questions.length;
      setCursor((c) => ({ ...c, [chip.group.topic]: next }));
      onRoute(chip.group.questions[next].text);
    } else {
      onRoute(chip.question.text);
    }
  };

  const idx = nearestLambdaIndex(lam);

  return (
    <Card className="relay-rise">
      <CardHead
        eyebrow="Panel 1"
        title="Ask"
        hint="Pick an incoming question or type your own, then set the dial."
        right={loading ? <Spinner label="routing" /> : null}
      />

      <div className="px-5 py-4">
        <div className="mb-2 flex items-baseline justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Today's questions
          </h3>
          <span className="text-[11px] text-slate-400">click again for another one</span>
        </div>
        <p className="mb-2 text-[10.5px] leading-tight text-slate-400">
          One question per topic, drawn from the held out split. Hover one for the exact text that
          gets embedded: some carry a few-shot primer, and the trailing{" "}
          <code className="text-slate-500">A:</code> is the model's cue to answer, not a missing
          answer.
        </p>

        <div className="relay-scroll grid max-h-[292px] gap-2 overflow-y-auto pr-1 sm:grid-cols-2 xl:grid-cols-1">
          {chips.map((chip) => {
            const active = activeQuestion === chip.question.text;
            return (
              <button
                key={chip.group.topic}
                onClick={() => clickChip(chip)}
                title={chip.question.text}
                className={`group rounded-xl border px-3 py-2.5 text-left transition ${
                  active
                    ? "border-brand-300 bg-gradient-to-r from-brand-50 to-plum-50 shadow-sm"
                    : "border-slate-200 bg-white hover:border-brand-200 hover:bg-brand-50/40"
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-base leading-none">{chip.group.emoji}</span>
                  <span className="min-w-0 truncate text-[13px] font-bold text-slate-800">
                    {chip.group.topic}
                  </span>
                  {chip.group.questions.length > 1 && (
                    <span className="ml-auto shrink-0 text-[10px] font-semibold text-slate-300 group-hover:text-brand-400">
                      {chip.index + 1}/{chip.group.questions.length}
                    </span>
                  )}
                </div>
                <div className="mt-0.5 text-[10.5px] italic text-slate-400">
                  asked by {chip.group.blurb}
                </div>
                <p className="mt-1 line-clamp-2 text-[12px] leading-snug text-slate-600">
                  {chip.question.label}
                </p>
              </button>
            );
          })}
          {!chips.length && (
            <div className="rounded-xl border border-dashed border-slate-200 px-3 py-6 text-center text-xs text-slate-400">
              loading today's questions
            </div>
          )}
        </div>
      </div>

      <div className="border-t border-slate-100 px-5 py-4">
        <h3 className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-500">
          Type your own question
        </h3>
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && (e.metaKey || e.ctrlKey) && draft.trim()) {
              onRoute(draft.trim());
            }
          }}
          rows={3}
          placeholder="Ask anything, for example: how do I balance a redox equation in acidic solution?"
          className="w-full resize-y rounded-xl border border-slate-200 bg-slate-50/60 px-3 py-2 text-[13px] leading-relaxed text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-brand-300 focus:bg-white focus:ring-2 focus:ring-brand-100"
        />
        <div className="mt-2 flex items-center justify-between gap-2">
          <span className="text-[10.5px] leading-tight text-slate-400">
            Embedded by the dataset's own encoder, all MiniLM L6 v2, normalised.
          </span>
          <button
            onClick={() => draft.trim() && onRoute(draft.trim())}
            disabled={!draft.trim() || loading}
            className="shrink-0 rounded-xl bg-gradient-to-r from-brand-500 to-plum-500 px-3.5 py-2 text-[12.5px] font-bold text-white shadow-sm transition hover:brightness-105 disabled:cursor-not-allowed disabled:opacity-40"
          >
            Route this question
          </button>
        </div>
      </div>

      <div className="rounded-b-2xl border-t border-slate-100 bg-slate-50/70 px-5 py-4">
        <div className="flex items-baseline justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Cost &#8596; Quality
          </h3>
          <Badge tone="plum">lambda = {fx(lam, lam >= 1 ? 2 : 3)}</Badge>
        </div>

        <input
          type="range"
          className="relay-slider mt-3 w-full"
          min={0}
          max={LAMBDA_STEPS.length - 1}
          step={1}
          value={idx}
          onChange={(e) => onLambda(LAMBDA_STEPS[Number(e.target.value)])}
        />

        <div className="mt-1.5 flex justify-between text-[10.5px] font-semibold text-slate-500">
          <span>
            Cost first
            <span className="block font-normal text-slate-400">cheapest models win</span>
          </span>
          <span className="text-right">
            Quality first
            <span className="block font-normal text-slate-400">lambda 0, price ignored</span>
          </span>
        </div>

        <p className="mt-2 text-[11.5px] leading-relaxed text-slate-500">
          {regime(lam)}. The platform team holds this dial, the router obeys it through
          <span className="font-semibold text-plum-700"> gamma + lambda x cost</span>.
        </p>
      </div>
    </Card>
  );
}
