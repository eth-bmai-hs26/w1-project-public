"""RelayAI Router Explorer, backend.

A thin HTTP shell over relay_router.RelayRouter. Every number in every response comes from
that module: no embedding, no gamma, no argmin is computed here.

Run from the repo root:
    uvicorn app.backend.main:app --reload --port 8000
"""

from __future__ import annotations

import math
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from relay_router import RelayRouter

BUNDLE_DIR = os.environ.get("RELAY_BUNDLE", "router_bundle")
REPO_ROOT = Path(__file__).resolve().parents[2]

r: RelayRouter | None = None


@asynccontextmanager
async def lifespan(_app: FastAPI):
    """One router for the process, loaded once, weights frozen."""
    global r
    bundle = Path(BUNDLE_DIR)
    if not bundle.is_absolute() and not bundle.exists():
        bundle = REPO_ROOT / bundle
    r = RelayRouter.load(bundle)
    r.warm()                      # pull the encoder in now, not on the first client request
    print(f"router ready: {r} from {bundle}")
    yield


app = FastAPI(
    lifespan=lifespan,
    title="RelayAI Router Explorer",
    version="1.0.0",
    description="Visualises RelayAI's trained neural network router. All inference runs "
                "through relay_router.RelayRouter.",
)

# local dev: the Vite server runs on another port
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


def router() -> RelayRouter:
    if r is None:                 # pragma: no cover, startup always runs first
        raise HTTPException(503, "router is still loading")
    return r


def clean(obj: Any) -> Any:
    """JSON cannot carry NaN. Ungraded cells become null."""
    if isinstance(obj, dict):
        return {k: clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean(v) for v in obj]
    if isinstance(obj, float) and not math.isfinite(obj):
        return None
    return obj


class RouteRequest(BaseModel):
    text: str = Field(..., min_length=1, description="the incoming question")
    lam: float = Field(0.2, ge=0.0, description="the cost dial, 0 spares no expense")
    pool: list[int] | None = Field(None, description="model ids to route over, default the pool")


@app.get("/health")
def health() -> dict:
    rr = router()
    return clean({"status": "ok", "router": repr(rr), **rr.info()})


@app.post("/route")
def route(req: RouteRequest) -> dict:
    """Route one question: the chosen model plus every number behind the decision."""
    rr = router()
    try:
        return clean(rr.route(req.text, lam=req.lam, pool=req.pool))
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.get("/models")
def models() -> dict:
    """The served pool and the full catalog, with size, cost and accuracy."""
    return clean(router().catalog())


@app.get("/models/{model_id}/stats")
def model_stats(model_id: int, lam: float = 0.2) -> dict:
    """Per topic accuracy measured and predicted, this model's output row, the pick rate."""
    rr = router()
    try:
        return clean(rr.model_stats(model_id, lam=lam))
    except ValueError as e:
        raise HTTPException(404, str(e))


@app.get("/pick_rates")
def pick_rates(lam: float = 0.2) -> dict:
    """Share of the sample questions every pool model wins at this lambda."""
    rr = router()
    try:
        rates = rr.pick_rates(lam=lam)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return clean({"lam": lam, "n_prompts": len(rr.sample_embeddings),
                  "rates": {str(k): v for k, v in rates.items()}})


@app.get("/topics")
def topics() -> dict:
    """The topics the traffic is made of, with how many held out questions each has."""
    return clean(router().topics())


@app.get("/categories")
def categories(top: int = 5) -> dict:
    """Per topic, the most accurate pool models measured on the test split, next to gamma."""
    return clean(router().category_leaders(top=top))


# There is deliberately no /add_model here. The output layer has one row per pool model and no
# row for anything else, so a model outside the pool cannot be scored at all. Closing that gap
# is the bonus part of the notebook, not something the app can fake.


@app.get("/sample_prompts")
def sample_prompts() -> dict:
    """Real held out questions, grouped by the topic they belong to."""
    rr = router()
    return clean({"groups": rr.sample_prompts(), "default_lambda": rr.default_lambda})
